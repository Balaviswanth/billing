<?php
$con=mysqli_connect("localhost","root","","shop");
mysqli_set_charset($con,'utf8');
?>